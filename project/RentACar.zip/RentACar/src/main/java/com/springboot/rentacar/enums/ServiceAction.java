package com.springboot.rentacar.enums;

public enum ServiceAction {
    Pending,
    Rented,
    Rejected,
    Canceled,
    Completed
}
