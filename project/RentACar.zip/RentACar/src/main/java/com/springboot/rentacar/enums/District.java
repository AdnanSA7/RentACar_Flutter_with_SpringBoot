package com.springboot.rentacar.enums;

public enum District {
}
