package com.springboot.rentacar.enums;

public enum CarServiceType {
    Hourly,
    Daily,
    RoundTrip
}
