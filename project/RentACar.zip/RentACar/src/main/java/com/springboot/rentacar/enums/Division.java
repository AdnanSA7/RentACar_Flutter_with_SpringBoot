package com.springboot.rentacar.enums;

public enum Division {
    Dhaka,
    Chittagong,
    Sylhet,
    Khulna,
    Rajshahi,
    Dinajpur,
    Barishal
}
