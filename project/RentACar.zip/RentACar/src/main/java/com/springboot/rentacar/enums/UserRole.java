package com.springboot.rentacar.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
