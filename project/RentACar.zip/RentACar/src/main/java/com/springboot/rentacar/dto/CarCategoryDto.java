package com.springboot.rentacar.dto;

import lombok.Data;

@Data
public class CarCategoryDto {
    private long id;
    private String category_name;
}
